// Colleges script removed — page deprecated.
// No runtime behavior. (Kept as placeholder to avoid missing file errors.)
